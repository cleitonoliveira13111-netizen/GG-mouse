package com.zyon.ggmousepremiumx

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs by lazy { getSharedPreferences("mapping", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF050D1F.toInt()
        window.navigationBarColor = 0xFF050D1F.toInt()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(0xFF050D1F.toInt())
        }
        fun text(value: String, size: Float, color: Int) = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(-1)
            setBackgroundColor(0xFF176BC0.toInt())
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply {
                bottomMargin = dp(9)
            }
        }
        fun field(hint: String, value: String) = EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
            setText(value)
            setTextColor(-1)
            setHintTextColor(0xFF8EAAC8.toInt())
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(0xFF102746.toInt())
        }

        panel.addView(text("GG MOUSE PREMIUM X", 24f, 0xFF65B8FF.toInt()))
        panel.addView(text("SHADOW EDITION  •  NO ROOT", 12f, 0xFFB7D9FF.toInt()))
        val description = text(
            "Editor de posições: informe coordenadas percentuais da tela (0 a 100). " +
            "A e B executam toques nesses pontos usando Acessibilidade.",
            13f, 0xFFE0ECFF.toInt()
        )
        description.setPadding(0, dp(16), 0, dp(14))
        panel.addView(description)

        panel.addView(text("Botão A — X / Y (%)", 14f, 0xFF65B8FF.toInt()))
        val ax = field("A X", (prefs.getFloat("ax", .78f) * 100).toInt().toString())
        val ay = field("A Y", (prefs.getFloat("ay", .78f) * 100).toInt().toString())
        val aRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        aRow.addView(ax, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        aRow.addView(ay, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        panel.addView(aRow)

        panel.addView(text("Botão B — X / Y (%)", 14f, 0xFF65B8FF.toInt()).apply {
            setPadding(0, dp(12), 0, dp(4))
        })
        val bx = field("B X", (prefs.getFloat("bx", .62f) * 100).toInt().toString())
        val by = field("B Y", (prefs.getFloat("by", .68f) * 100).toInt().toString())
        val bRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bRow.addView(bx, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        bRow.addView(by, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        panel.addView(bRow)

        panel.addView(button("Salvar posições") {
            fun read(e: EditText, fallback: Float): Float =
                (e.text.toString().toFloatOrNull()?.coerceIn(0f, 100f)?.div(100f) ?: fallback)
            prefs.edit()
                .putFloat("ax", read(ax, .78f)).putFloat("ay", read(ay, .78f))
                .putFloat("bx", read(bx, .62f)).putFloat("by", read(by, .68f))
                .apply()
            Toast.makeText(this, "Posições salvas", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(12), 0, 0) })

        panel.addView(button("Permitir sobreposição") {
            if (!Settings.canDrawOverlays(this)) startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        panel.addView(button("Ativar serviço de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        panel.addView(button("Iniciar painel flutuante") {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        })
        panel.addView(button("Parar painel") { stopService(Intent(this, OverlayService::class.java)) })
        setContentView(panel)
    }
}
