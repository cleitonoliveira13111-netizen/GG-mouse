package com.zyon.ggmousepremiumx

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class MapperAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var current: MapperAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    fun tapAt(normalizedX: Float, normalizedY: Float) {
        val x = normalizedized(normalizedX) * resources.displayMetrics.widthPixels
        val y = normalizedized(normalizedY) * resources.displayMetrics.heightPixels
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 65))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun normalizedized(value: Float) = value.coerceIn(0.02f, 0.98f)

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false
        val prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        when (event.keyCode) {
            KeyEvent.KEYCODE_1 -> {
                tapAt(prefs.getFloat("ax", .78f), prefs.getFloat("ay", .78f))
                return true
            }
            KeyEvent.KEYCODE_2 -> {
                tapAt(prefs.getFloat("bx", .62f), prefs.getFloat("by", .68f))
                return true
            }
        }
        return false
    }
}
