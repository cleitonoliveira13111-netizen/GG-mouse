package com.zyon.ggmousepremiumx

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(0xEE071A35.toInt())
        }

        val label = TextView(this).apply {
            text = "SHADOW"
            textSize = 11f
            setTextColor(0xFF65B8FF.toInt())
            setPadding(dp(5), 0, dp(8), 0)
            contentDescription = "Segure aqui para mover o painel"
        }

        fun keyButton(title: String) = Button(this).apply {
            text = title
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF176BC0.toInt())
            setOnClickListener {
                val prefs = getSharedPreferences("mapping", MODE_PRIVATE)
                val xKey = if (title == "A") "ax" else "bx"
                val yKey = if (title == "A") "ay" else "by"
                val defaultX = if (title == "A") .78f else .62f
                val defaultY = if (title == "A") .78f else .68f
                val service = MapperAccessibilityService.current
                if (service == null) {
                    Toast.makeText(this@OverlayService,
                        "Ative o serviço de acessibilidade do app primeiro",
                        Toast.LENGTH_SHORT).show()
                } else {
                    service.tapAt(
                        prefs.getFloat(xKey, defaultX),
                        prefs.getFloat(yKey, defaultY)
                    )
                }
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(42)).apply {
                marginStart = dp(4)
            }
        }

        bar.addView(label)
        bar.addView(keyButton("A"))
        bar.addView(keyButton("B"))
        bar.addView(Button(this).apply {
            text = "×"
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF8B2635.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply {
                marginStart = dp(4)
            }
            setOnClickListener { stopSelf() }
        })

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(100)
        }

        label.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = params.x
                    dragStartY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = dragStartX + (event.rawX - touchStartX).toInt()
                    params.y = dragStartY + (event.rawY - touchStartY).toInt()
                    runCatching { wm.updateViewLayout(bar, params) }
                    true
                }
                else -> true
            }
        }

        root = bar
        runCatching { wm.addView(bar, params) }.onFailure {
            Toast.makeText(this, "Não foi possível exibir a sobreposição", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private var dragStartX = 0
    private var dragStartY = 0
    private var touchStartX = 0f
    private var touchStartY = 0f

    override fun onDestroy() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
