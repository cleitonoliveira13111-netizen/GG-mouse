# GG Mouse Premium X — Shadow Edition

Projeto Android original, sem root. Inclui painel flutuante, dois botões de toque configuráveis por coordenadas percentuais e atalhos de teclado 1/2 via serviço de Acessibilidade.

## Requisitos
- Android Studio recente ou Gradle 8.9
- JDK 17
- Android SDK Platform 35
- POCO F7 / Android 14+ para teste real (compatibilidade depende do jogo)

## Gerar APK localmente
Na pasta do projeto:
```bash
gradle --no-daemon :app:assembleDebug
```
O APK será gerado em:
`app/build/outputs/apk/debug/app-debug.apk`

## Gerar APK automaticamente
O repositório inclui `.github/workflows/android-apk.yml`. Envie o projeto para um repositório GitHub e execute a ação **Build Android APK** na aba Actions. O APK será disponibilizado como artefato para download.

## Instalação e configuração
1. Instale o APK.
2. Abra o app e conceda a permissão **Sobrepor a outros apps**.
3. Em Acessibilidade, ative **GG Mouse Premium X**.
4. Ajuste X/Y dos botões A e B entre 0 e 100 e salve.
5. Inicie o painel flutuante. Arraste pela palavra SHADOW; toque em A ou B para executar o toque configurado.
6. Teclas físicas 1 e 2 executam os mesmos pontos, se o dispositivo/teclado e o Android permitirem a captura.

## Limitações reais
- Este é um mapeador simples de toques, não um clone do GG Mouse Pro.
- Não implementa joystick analógico, controle contínuo da câmera pelo mouse, macros complexas, perfis automáticos por jogo ou bypass de anticheat.
- O Android e alguns jogos podem bloquear gestos de Acessibilidade, sobreposições ou captura de teclas. A compatibilidade deve ser validada no jogo pretendido.
- A compilação de depuração não é assinada para publicação na Play Store.
